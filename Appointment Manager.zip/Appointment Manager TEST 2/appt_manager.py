import os
from appointment import Appointment

day_of_the_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

def create_weekly_calendar():
    calendar = []
    for day in day_of_the_week:
        for hour in range(9, 17):  # Appointments from 9 AM to 4 PM (last slot ends at 5 PM)
            calendar.append(Appointment(day, hour))
    return calendar

def load_scheduled_appointments(appointments):
    filename = input("Enter the filename to load appointments from: ")

    if not os.path.exists(filename):
        filename = input("File not found. Re-enter appointment name: ")

    with open(filename, 'r') as file:
        lines = file.readlines()
        for line in lines:
                client_name, client_phone, appt_type, day, start_time_hour = line.strip().split(',')
                appointment = find_appointment_by_time(appointments, day, int(start_time_hour))
                if appointment:
                    appointment.schedule(client_name, client_phone, int(appt_type))
    print(f"{len(lines)} previously scheduled appointments have been loaded")
    return len(lines)

def find_appointment_by_time(appointments, day, start_hour):
    for appointment in appointments:
        if appointment.get_day_of_week() == day and appointment.get_start_time_hour() == start_hour:
            return appointment
    return

def show_appointments_by_name(appointments, name):
    matches_by_name = []
    for appt in appointments:
        if name.lower() in appt.get_client_name().lower():
            matches_by_name.append(appt)
    
    if matches_by_name:
        for appt in matches_by_name:
            print(appt)

    else:
        print(f"No appointments found.")

def show_appointments_by_day(appointments, day):
    matches_by_day = []
    for appt in appointments:
        if appt.get_day_of_week() == day:
            matches_by_day.append(appt)
    
    if matches_by_day:
        for appt in matches_by_day:
            print(appt)
    else:
        print(f"\nNo appointments found.\n")

# Receives the list of Appointment’s objects
def change_appointment_by_day_time(appointments):

    # Asks the user to enter the day and the start hour for the appointment which will be changed
    day = input("Whatday: ").title()
    start_hour = int(input("Enter start hour (24 hour clock): "))
    appointment = find_appointment_by_time(appointments, day, start_hour)

    # After ensuring that the appointment exists in the calendar:
    if not appointment:
        print("No appointment found at the given time.")
        return
    # Asks the user for the new day and new start hour
    new_day = input("Enter a new day: ").title()
    new_start_hour = int(input("Enter start hour (24 hour clock): "))
    new_appointment = find_appointment_by_time(appointments, new_day, new_start_hour)

    # 
    if new_appointment and new_appointment.get_appt_type() == 0:
        new_appointment.schedule(appointment.get_client_name(), appointment.get_client_phone(), appointment.get_appt_type())
        appointment.cancel()
        # Finally displays a confirmation message which includes the client name and the new appointment day and time.
        print(f"Appointment rescheduled {appointment.get_client_name()} has been changed to \nDay = {new_day}\nTime = {new_start_hour}:00")
    else:
        print("The new time slot is already booked\n")

# This calculates the  fees for the day th user wants to open
def calculate_fees_per_day(appointments):
    # The user inputs the day they want
    day = input("Enter the day to calculate fees: ").title()
    # This will check if the day inputed is within the days of the week the store is open.
    if day not in day_of_the_week:
        print(f"{day} is invalid or the salon is closed\n")
        return
    # This is to initialize the fees to be calculated
    total_fees = 0
    # This adds all the fees aassociated to the day entered and print the total fees
    for appt in appointments:
        if appt.get_day_of_week() == day and appt.get_appt_type() != 0:
            total_fees += Appointment.appt_fee_dict[appt.get_appt_type()]
    
    print(f"Total fees for {day}: ${total_fees}\n")

# This calculates the weekly fees for the whole week
def calculate_weekly_fees(appointments):
    total_fees = 0
    # This adds all the fees aassociated to the day entered and print the total fees
    for appt in appointments:
        if appt.get_appt_type() != 0:
            total_fees += Appointment.appt_fee_dict[appt.get_appt_type()]
    
    print(f"Total weekly fees: ${total_fees}\n")

    # This saves the current configuration to a file 
def save_scheduled_appointments(appointments):
    filename = input("Enter appointment filename: ")
    if os.path.exists(filename):
        overwrite = input("File already exists. Do you want to overwrite it (Y/N)? ").lower()
        if overwrite != 'y':
            filename = input("Enter appointment filename: ")
    
    # writes the appointment to the file in the proper CSV format
    with open(filename, 'w') as file:
        # Iterates over each appointment in the list
        for appt in appointments:
            if appt.get_appt_type() != 0:
                file.write(appt.format_record() + '\n')
    print(f"3 scheduled appointments have been successfully saved")

def print_menu():
    print("="*38)
    print(f'{"Hair Salon Appointment Manager":^38}')
    print("="*38)
    print("1. Schedule an appointment\n"
          "2. Find appointment by name\n"
          "3. Print calendar for a specific day\n"
          "4. Cancel an appointment\n"
          "5. Change an appointment\n"
          "6. Calculate total fees for a day\n"
          "7. Calculate total weekly fees\n"
          "9. Exit the system")

def calendar_header():
                    print("\n{:20s}{:15s}{:10s}{:10s}{:10s}{:20s}".format("Client Name",
        "Phone", "Day", "Start", "End", "Type"))
                    print("-"*85,)

# This is a function that will set an appointment
def schedule_appt(appointments):
    print("** Schedule an appointment **")
    day = input("What day: ").title()


    start_hour = input("Enter start hour (24-hour clock): ")
    # This will return back into the menu when the user accidentally enters a letter instead of a number
    if not start_hour.isdigit():
        print("Invalid hour.")
        return

    start_hour = int(start_hour)
    
    # Ensure time is within the working hours (9 to 17)
    if start_hour < 9 or start_hour >= 17:
        print("Sorry that time slot is not in the weekly calendar!\n")
        return
    # This is to set the clients name, the day they want and the time they want the appointment
    appointment = find_appointment_by_time(appointments, day, start_hour)
    if appointment:
        # This is to get the appoinment type from the appointment calss
        if appointment and appointment.get_appt_type() == 0:
            client_name = input("Client Name: ")
            client_phone = input("Client Phone: ")
            print("Appointment types:\n1: Mens Cut $40, 2: Ladies Cut $60, 3: Mens Colouring $40, 4: Ladies Colouring $80")
            
            # This is to ensure the input is a number instead of a letter or a character
            appt_type = input("Type of Appointment: ")
            if not appt_type.isdigit():
                print("Invalid type.")
                return

            # This is tp create a schedule for the client using the schedule setter from appointment class then displays it is scheduled
            # This will also display if the time slot is  taken or is not available
            appt_type = int(appt_type)
            if appt_type in Appointment.appt_type_dict:
                appointment.schedule(client_name, client_phone, appt_type)
                print(f"OK, {client_name}'s appointment is scheduled!\n")
            else:
                print("Invalid appointment type.")
        else: print("Sorry that time slot is booked already!\n")
    else:
        print("Sorry that time slot is not in the weekly calendar!\n")


def main():
    appointments = create_weekly_calendar()
    print("Starting the Appointment Manager System\nWeekly calendar created")

    load_choice = input("Would you like to load previously scheduled appointments from a file (Y/N)? ").lower()
    if load_choice == 'y':
        load_scheduled_appointments(appointments)
    
    print_menu()
    user_choice = int(input("Enter your selection: "))

    while user_choice != 10:

        if user_choice == 1:
            schedule_appt(appointments)

        elif user_choice == 2:
            print("** Find an appointment by name **")
            name = input("Enter client name: ")
            print(f"Appointments for {name}")
            calendar_header()
            print("\n")
            show_appointments_by_name(appointments, name)

        elif user_choice == 3:
            print("\n** Print calendar for a specific day **")
            day = input("Enter day of week: ").title()
            if day not in day_of_the_week:
                print(f"Appointments for {day}")
                calendar_header()
            show_appointments_by_day(appointments, day)
            print("\n")

        elif user_choice == 4:
            day = input("What day: ").title()
            start_hour = input("Enter start hour (24-hour clock): ")
            
            if not start_hour.isdigit():
                print("Invalid hour.")
            else:
                start_hour = int(start_hour)
            appointment = find_appointment_by_time(appointments, day, start_hour)
            if appointment and appointment.get_appt_type() != 0:
                cancelled_name = appointment.get_client_name()
                appointment.cancel()
                print(f"Appointment: {day} {start_hour}:00 - {start_hour + 1}:00 for {cancelled_name} has been cancelled!\n")
            else:
                print("That time slot isn't booked and doesn't need to be cancelled\n")

        elif user_choice == 5:
            print("\n")
            print("Change an appointment for:")
            change_appointment_by_day_time(appointments)

        elif user_choice == 6:
            print("Fees calculation per day....")
            calculate_fees_per_day(appointments)

        elif user_choice == 7:
            calculate_weekly_fees(appointments)
        
        elif user_choice == 8:
            print("\nInvalid option\n")

        elif user_choice == 9:
            print("** Exit the system **")
            save_choice = input("Would you like to save all scheduled appointments to a file (Y/N)? ").lower()
            if save_choice == 'y':
                save_scheduled_appointments(appointments)
            print("Good Bye!")
            break

        elif user_choice > 9:
                print("Invalid option\n")
                print_menu()
                user_choice = int(input("Enter your selection: "))

        print_menu()
        user_choice = int(input("Enter your selection: "))


if __name__ == "__main__":
    main()
